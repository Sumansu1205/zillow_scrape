import pandas as pd

df = pd.read_csv('/Users/surabhisuman/Downloads/marketing_campaign.csv')
print()